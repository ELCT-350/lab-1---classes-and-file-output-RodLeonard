#include "Rectangle.h"

using namespace ELCT350;

Rectangle::Rectangle(double length, double width)
         : _length(length), _width(width)
{
  /*_length = length;
  _width = width;*/
}