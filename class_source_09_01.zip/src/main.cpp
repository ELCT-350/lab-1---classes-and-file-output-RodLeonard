#include <iostream>
#include <fstream>
#include <cmath>


//1. Create a function that computes the NEXT prime number and returns it
//2. Output all the primes that exist in between [1-20]

using namespace std;

enum ErrorCodes
{
  Ok = 0
};

int nextPrime(int start)
{
  if(start <= 1)
    start = 1;

  int current = start + 1;
  int prime = 0;
  do
  {
    bool isPrime = true;
    for(int multiple = 2; (multiple <= ceil(sqrt(current))) && isPrime; ++multiple)
    {
      if(current != multiple && current % multiple == 0)
        isPrime = false;
    }

    if(isPrime)
      prime = current;
    else
      current++;
  }
  while(prime == 0);

  return prime;
}

int main()
{
  const int SEARCH_START = 1;
  const int SEARCH_STOP = 20;
  /*
  cout << "Do while: " << endl;
  int num = nextPrime(SEARCH_START);
  do
  {
    cout << num << endl;    
    num = nextPrime(num);
  }
  while(num <= SEARCH_STOP);
  /*/
  cout << "for loop: " << endl;
  for(int num = nextPrime(SEARCH_START); num <= SEARCH_STOP; num = nextPrime(num))
  {
    cout << num << endl;
  }
  //*/
  return Ok;
}